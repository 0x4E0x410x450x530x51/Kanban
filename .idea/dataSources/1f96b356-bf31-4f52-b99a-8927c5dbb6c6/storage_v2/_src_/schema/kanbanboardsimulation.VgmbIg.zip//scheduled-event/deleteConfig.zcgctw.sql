create definer = root@localhost event deleteConfig on schedule
    every '1' HOUR
        starts '2022-07-20 11:28:43'
    on completion preserve
    enable
    do
    BEGIN
DELETE FROM SettingsConfiguration WHERE (SELECT creationDate FROM Board Where SettingsConfiguration.boardUUID = UUID) < DATE_SUB(NOW(), INTERVAL 3 DAY);
END;

